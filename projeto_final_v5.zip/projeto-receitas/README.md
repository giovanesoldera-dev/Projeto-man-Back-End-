# Projeto 1 - Portfólio de Receitas UTFPR

Este projeto foi desenvolvido como parte da disciplina de Programação Web Back-End. Ele integra um banco de dados relacional (PostgreSQL) para a estrutura principal e um banco não relacional (MongoDB) para o sistema de comentários.

## Tecnologias Utilizadas
- **Node.js** com **Express**
- **Sequelize** (ORM para PostgreSQL)
- **Mongoose** (ODM para MongoDB)
- **Handlebars** (Template Engine)
- **Bcryptjs** (Criptografia de senhas)
- **Express-session** & **Connect-flash** (Autenticação e mensagens)

## Requisitos Atendidos
- [x] Autenticação de Alunos e Administrador.
- [x] CRUD de Receitas (N:N com Categorias e Alunos).
- [x] Gerenciamento de Habilidades dos Alunos (N:N com campo extra de nível).
- [x] Comentários persistidos no MongoDB.
- [x] Relatório público de habilidades.
- [x] Visualização pública de receitas.
- [x] Arquitetura MVC.

## Como Executar

1. Instale as dependências:
   ```bash
   npm install
   ```

2. **Configuração do Banco de Dados (PostgreSQL):**
   - Certifique-se de que o PostgreSQL está rodando em sua máquina.
   - Crie um banco de dados chamado `projeto_receitas`.
   - No arquivo `.env`, preencha `DB_USER` e `DB_PASS` com suas credenciais do PostgreSQL.

3. Execute o script de seed para criar o administrador inicial:
   ```bash
   node seed.js
   ```

4. Inicie o servidor:
   ```bash
   npm start
   ```

**Credenciais do Admin Padrão:**
- **Email:** admin@utfpr.edu.br
- **Senha:** admin123
