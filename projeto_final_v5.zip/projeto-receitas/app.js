const express = require('express');
const { engine } = require('express-handlebars');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');
const methodOverride = require('method-override');
require('dotenv').config();

const { sequelize } = require('./models/mysql');
const connectMongo = require('./config/mongo');

const app = express();

// Conectar Bancos de Dados
connectMongo();
sequelize.sync({ force: false }).then(() => console.log('PostgreSQL Sincronizado'));

// Handlebars Config
app.engine('handlebars', engine({
    defaultLayout: 'main',
    helpers: {
        multiply: (a, b) => a * b,
        isAdminUser: (user) => user && user.role === 'admin',
        eq: (a, b) => String(a) === String(b),
        split: (str, delimiter) => str.split(delimiter)
    },
    runtimeOptions: {
        allowProtoPropertiesByDefault: true,
        allowProtoMethodsByDefault: true,
    }
}));
app.set('view engine', 'handlebars');

// Middlewares
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true
}));

app.use(flash());

// Global Variables
app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.user = req.session.user || null;
    next();
});

// Importar Controllers
const RecipeController = require('./controllers/RecipeController');
const upload = require('./config/multer');
const AuthController = require('./controllers/AuthController');
const StudentController = require('./controllers/StudentController');
const AdminController = require('./controllers/AdminController');
const CommentController = require('./controllers/CommentController');
const { isLoggedIn, isAdmin } = require('./middlewares/auth');

// --- ROTAS ---

// Autenticação
app.get('/login', AuthController.showLogin);
app.post('/login', AuthController.login);
app.get('/logout', AuthController.logout);

// Receitas (Públicas e Privadas)
// IMPORTANTE: Rotas estáticas devem vir ANTES das rotas com parâmetros (:id)
app.get('/', RecipeController.listAll);
app.get('/recipes/create', isLoggedIn, RecipeController.showCreateForm);
app.post('/recipes/create', isLoggedIn, upload.single('image'), RecipeController.create);
app.get('/recipes/edit/:id', isLoggedIn, RecipeController.showEditForm);
app.post('/recipes/edit/:id', isLoggedIn, upload.single('image'), RecipeController.update);
app.delete('/recipes/delete/:id', isLoggedIn, RecipeController.delete);
app.get('/recipes/:id', RecipeController.showDetails); // Esta deve ser a última de receitas
app.post('/recipes/:id/comments', CommentController.create);

// Dashboard e Habilidades do Aluno
app.get('/dashboard', isLoggedIn, StudentController.dashboard);
app.get('/student/skills', isLoggedIn, StudentController.manageSkills);
app.post('/student/skills/add', isLoggedIn, StudentController.addSkill);
app.post('/student/skills/remove/:id', isLoggedIn, StudentController.removeSkill);

// Admin - Dashboard e Alunos
app.get('/admin', isLoggedIn, isAdmin, AdminController.dashboard);
app.get('/admin/students', isLoggedIn, isAdmin, AdminController.listStudents);
app.post('/admin/students/create', isLoggedIn, isAdmin, AdminController.createStudent);

// Admin - Categorias
app.get('/admin/categories', isLoggedIn, isAdmin, AdminController.listCategories);
app.post('/admin/categories/create', isLoggedIn, isAdmin, AdminController.createCategory);

// Admin - Habilidades
app.get('/admin/skills', isLoggedIn, isAdmin, AdminController.listSkills);
app.post('/admin/skills/create', isLoggedIn, isAdmin, AdminController.createSkill);

// Relatório (Público)
app.get('/reports/skills', async (req, res) => {
    try {
        const { Skill, User } = require('./models/mysql');
        const skills = await Skill.findAll({ include: [User] });
        const totalStudents = await User.count({ where: { role: 'student' } });
        
        const report = skills.map(s => ({
            name: s.name,
            count: s.Users ? s.Users.length : 0,
            percentage: totalStudents > 0 ? (((s.Users ? s.Users.length : 0) / totalStudents) * 100).toFixed(1) : 0
        }));
        
        res.render('reports/skills', { report });
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao gerar relatório');
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
