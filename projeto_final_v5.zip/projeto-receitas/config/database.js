const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASS,
    {
        host: process.env.DB_HOST,
        port: process.env.DB_PORT || 5432,
        dialect: process.env.DB_DIALECT,
        logging: false,
        dialectOptions: {
            // Algumas hospedagens de PostgreSQL exigem SSL
            // ssl: {
            //     require: true,
            //     rejectUnauthorized: false
            // }
        }
    }
);

module.exports = sequelize;
