const { User, Category, Skill } = require('../models/mysql');
const bcrypt = require('bcryptjs');

class AdminController {
    async dashboard(req, res) {
        res.render('admin/dashboard');
    }

    // CRUD Alunos
    async listStudents(req, res) {
        const students = await User.findAll({ where: { role: 'student' } });
        res.render('admin/students/list', { students: students.map(s => s.toJSON()) });
    }

    async createStudent(req, res) {
        const { name, email, password } = req.body;
        try {
            const hashedPassword = await bcrypt.hash(password, 10);
            await User.create({ name, email, password: hashedPassword, role: 'student' });
            req.flash('success_msg', 'Aluno cadastrado com sucesso!');
            res.redirect('/admin/students');
        } catch (error) {
            req.flash('error_msg', 'Erro ao cadastrar aluno.');
            res.redirect('/admin/students');
        }
    }

    // CRUD Categorias
    async listCategories(req, res) {
        const categories = await Category.findAll();
        res.render('admin/categories/list', { categories: categories.map(c => c.toJSON()) });
    }

    async createCategory(req, res) {
        await Category.create({ name: req.body.name });
        res.redirect('/admin/categories');
    }

    // CRUD Habilidades
    async listSkills(req, res) {
        const skills = await Skill.findAll();
        res.render('admin/skills/list', { skills: skills.map(s => s.toJSON()) });
    }

    async createSkill(req, res) {
        await Skill.create({ name: req.body.name });
        res.redirect('/admin/skills');
    }
}

module.exports = new AdminController();
