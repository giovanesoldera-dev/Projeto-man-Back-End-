const { User } = require('../models/mysql');
const bcrypt = require('bcryptjs');

class AuthController {
    showLogin(req, res) {
        res.render('login');
    }

    async login(req, res) {
        const { email, password } = req.body;

        try {
            const user = await User.findOne({ where: { email } });

            if (!user) {
                req.flash('error_msg', 'Usuário não encontrado.');
                return res.redirect('/login');
            }

            const isMatch = await bcrypt.compare(password, user.password);

            if (!isMatch) {
                req.flash('error_msg', 'Senha incorreta.');
                return res.redirect('/login');
            }

            req.session.user = {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            };

            req.flash('success_msg', `Bem-vindo, ${user.name}!`);
            res.redirect('/dashboard');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao realizar login.');
            res.redirect('/login');
        }
    }

    logout(req, res) {
        req.session.destroy();
        res.redirect('/login');
    }
}

module.exports = new AuthController();
