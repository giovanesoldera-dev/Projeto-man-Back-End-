const Comment = require('../models/mongo/Comment');

class CommentController {
    async create(req, res) {
        const { authorName, content } = req.body;
        const { id } = req.params; // O parâmetro na rota é :id

        try {
            await Comment.create({
                recipeId: id,
                authorName,
                content
            });
            req.flash('success_msg', 'Comentário enviado!');
            res.redirect(`/recipes/${id}`);
        } catch (error) {
            console.error('Erro ao salvar comentário:', error);
            req.flash('error_msg', 'Erro ao enviar comentário. Verifique se o MongoDB está rodando.');
            res.redirect(`/recipes/${id}`);
        }
    }
}

module.exports = new CommentController();
