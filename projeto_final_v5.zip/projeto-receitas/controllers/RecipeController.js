const { Recipe, Category, User } = require('../models/mysql');
const Comment = require('../models/mongo/Comment');

class RecipeController {
    async listAll(req, res) {
        try {
            const { categoryId } = req.query;
            const filter = categoryId ? { include: [{ model: Category, where: { id: categoryId } }, { model: User, as: 'Authors' }] } : { include: [{ model: Category }, { model: User, as: 'Authors' }] };
            
            const recipes = await Recipe.findAll(filter);
            const categories = await Category.findAll();
            
            res.render('home', { 
                recipes: recipes.map(r => r.toJSON()),
                categories: categories.map(c => c.toJSON()),
                selectedCategory: categoryId
            });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao buscar receitas');
        }
    }

    async showDetails(req, res) {
        try {
            const recipe = await Recipe.findByPk(req.params.id, {
                include: [
                    { model: Category },
                    { model: User, as: 'Authors' }
                ]
            });
            
            if (!recipe) {
                req.flash('error_msg', 'Receita não encontrada.');
                return res.redirect('/');
            }

            let comments = [];
            try {
                // Tenta buscar comentários, mas não trava se o MongoDB falhar
                const mongoComments = await Comment.find({ recipeId: req.params.id }).sort({ createdAt: -1 }).limit(50);
                comments = mongoComments.map(c => c.toObject());
            } catch (mongoError) {
                console.error('Erro ao buscar comentários no MongoDB:', mongoError.message);
                // Continua sem comentários
            }

            res.render('recipes/details', { 
                recipe: recipe.toJSON(), 
                comments: comments
            });
        } catch (error) {
            console.error('Erro Fatal nos Detalhes:', error);
            res.status(500).send('Erro interno ao carregar a página. Verifique se o banco de dados está rodando.');
        }
    }

    async showCreateForm(req, res) {
        try {
            const categories = await Category.findAll();
            const { Op } = require('sequelize');
            const students = await User.findAll({ 
                where: { 
                    role: 'student',
                    id: { [Op.ne]: req.session.user.id } // Exclui o usuário logado
                } 
            });
            res.render('recipes/create', { 
                categories: categories.map(c => c.toJSON()),
                students: students.map(s => s.toJSON())
            });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao carregar formulário');
        }
    }

    async create(req, res) {
        const { name, description, external_link, categories, authors } = req.body;
        const image = req.file ? `/uploads/${req.file.filename}` : null;
        try {
            const recipe = await Recipe.create({ name, description, external_link, image });
            
            if (categories) await recipe.setCategories(categories);
            
            const authorIds = Array.isArray(authors) ? authors : (authors ? [authors] : []);
            if (!authorIds.includes(req.session.user.id.toString())) {
                authorIds.push(req.session.user.id);
            }
            await recipe.setAuthors(authorIds);

            req.flash('success_msg', 'Receita criada com sucesso!');
            res.redirect('/dashboard');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao criar receita.');
            res.redirect('/recipes/create');
        }
    }

    async showEditForm(req, res) {
        try {
            const recipe = await Recipe.findByPk(req.params.id, {
                include: [{ model: Category }, { model: User, as: 'Authors' }]
            });
            
            if (!recipe) return res.status(404).send('Receita não encontrada');

            const isAuthor = recipe.Authors.some(author => author.id === req.session.user.id);
            if (!isAuthor && req.session.user.role !== 'admin') {
                req.flash('error_msg', 'Você não tem permissão para editar esta receita.');
                return res.redirect('/dashboard');
            }

            const categories = await Category.findAll();
            const { Op } = require('sequelize');
            const students = await User.findAll({ 
                where: { 
                    role: 'student',
                    id: { [Op.ne]: req.session.user.id }
                } 
            });
            
            res.render('recipes/edit', { 
                recipe: recipe.toJSON(),
                categories: categories.map(c => c.toJSON()),
                students: students.map(s => s.toJSON())
            });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao carregar formulário de edição');
        }
    }

    async update(req, res) {
        const { name, description, external_link, categories, authors } = req.body;
        const updateData = { name, description, external_link };
        if (req.file) updateData.image = `/uploads/${req.file.filename}`;

        try {
            const recipe = await Recipe.findByPk(req.params.id, {
                include: [{ model: User, as: 'Authors' }]
            });

            const isAuthor = recipe.Authors.some(author => author.id === req.session.user.id);
            if (!isAuthor && req.session.user.role !== 'admin') {
                req.flash('error_msg', 'Permissão negada.');
                return res.redirect('/dashboard');
            }

            await recipe.update(updateData);
            if (categories) await recipe.setCategories(categories);
            if (authors) await recipe.setAuthors(authors);

            req.flash('success_msg', 'Receita atualizada!');
            res.redirect('/dashboard');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao atualizar receita.');
            res.redirect(`/recipes/edit/${req.params.id}`);
        }
    }

    async delete(req, res) {
        try {
            const recipe = await Recipe.findByPk(req.params.id, {
                include: [{ model: User, as: 'Authors' }]
            });
            const isAuthor = recipe.Authors.some(author => author.id === req.session.user.id);
            if (!isAuthor && req.session.user.role !== 'admin') {
                req.flash('error_msg', 'Permissão negada.');
                return res.redirect('/dashboard');
            }
            await recipe.destroy();
            req.flash('success_msg', 'Receita excluída!');
            res.redirect('/dashboard');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao excluir receita.');
            res.redirect('/dashboard');
        }
    }
}

module.exports = new RecipeController();
