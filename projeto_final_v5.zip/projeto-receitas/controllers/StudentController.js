const { User, Recipe, Skill, StudentSkill, Category } = require('../models/mysql');

class StudentController {
    async dashboard(req, res) {
        try {
            const user = await User.findByPk(req.session.user.id, {
                include: [
                    { model: Recipe, as: 'AuthoredRecipes', include: [Category] },
                    { model: Skill }
                ]
            });
            res.render('student/dashboard', { user: user.toJSON() });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao carregar dashboard');
        }
    }

    async manageSkills(req, res) {
        try {
            const allSkills = await Skill.findAll();
            const user = await User.findByPk(req.session.user.id, {
                include: [Skill]
            });
            res.render('student/skills', { 
                allSkills: allSkills.map(s => s.toJSON()),
                userSkills: user.Skills.map(s => s.toJSON())
            });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao carregar habilidades');
        }
    }

    async addSkill(req, res) {
        const { skillId, level } = req.body;
        try {
            const user = await User.findByPk(req.session.user.id);
            await user.addSkill(skillId, { through: { level } });
            req.flash('success_msg', 'Habilidade adicionada!');
            res.redirect('/student/skills');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao adicionar habilidade.');
            res.redirect('/student/skills');
        }
    }

    async removeSkill(req, res) {
        try {
            const user = await User.findByPk(req.session.user.id);
            await user.removeSkill(req.params.id);
            req.flash('success_msg', 'Habilidade removida!');
            res.redirect('/student/skills');
        } catch (error) {
            console.error(error);
            req.flash('error_msg', 'Erro ao remover habilidade.');
            res.redirect('/student/skills');
        }
    }
}

module.exports = new StudentController();
