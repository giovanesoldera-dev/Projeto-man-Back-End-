module.exports = {
    isLoggedIn: (req, res, next) => {
        if (req.session.user) {
            return next();
        }
        req.flash('error_msg', 'Você precisa estar logado para acessar esta página.');
        res.redirect('/login');
    },
    isAdmin: (req, res, next) => {
        if (req.session.user && req.session.user.role === 'admin') {
            return next();
        }
        req.flash('error_msg', 'Acesso negado. Apenas administradores podem acessar esta página.');
        res.redirect('/dashboard');
    }
};
