const User = require('./User');
const Recipe = require('./Recipe');
const Category = require('./Category');
const Skill = require('./Skill');
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

// Relacionamento N:N entre Receita e Categoria
Recipe.belongsToMany(Category, { through: 'RecipeCategory' });
Category.belongsToMany(Recipe, { through: 'RecipeCategory' });

// Relacionamento N:N entre Receita e Aluno (User)
Recipe.belongsToMany(User, { through: 'RecipeStudent', as: 'Authors' });
User.belongsToMany(Recipe, { through: 'RecipeStudent', as: 'AuthoredRecipes' });

// Relacionamento N:N entre Aluno (User) e Habilidade (Skill) com campo extra 'level'
const StudentSkill = sequelize.define('StudentSkill', {
    level: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            min: 0,
            max: 10
        }
    }
});

User.belongsToMany(Skill, { through: StudentSkill });
Skill.belongsToMany(User, { through: StudentSkill });

module.exports = {
    User,
    Recipe,
    Category,
    Skill,
    StudentSkill,
    sequelize
};
