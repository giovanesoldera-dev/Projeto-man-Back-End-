const { User, sequelize } = require('./models/mysql');
const bcrypt = require('bcryptjs');

async function seed() {
    await sequelize.sync({ force: true });
    
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    await User.create({
        name: 'Administrador',
        email: 'admin@utfpr.edu.br',
        password: hashedPassword,
        role: 'admin'
    });

    console.log('Admin criado com sucesso!');
    console.log('Email: admin@utfpr.edu.br');
    console.log('Senha: admin123');
    process.exit();
}

seed();
